#' Autocorrelation Plot
#' 
#' Plots current vs lagged residuals along with quadrants dividing these
#' residuals about the value zero.
#' 
#' 
#' @param fit output from the function "lm()".
#' @return Plots current vs lagged residuals along with quadrants dividing
#' these residuals about the value zero.
#' @keywords hplot
#' @examples
#' 
#' data(airpass.df)
#' time<-1:144
#' airpass.fit<-lm(passengers~time, data = airpass.df)
#' autocor.plot(airpass.fit)
#' 
#' @export autocor.plot
autocor.plot<- function(fit){
    current.res <- fit$residuals[-1]
    T <- length(fit$residuals)
    lagged.res <- fit$residuals[-T]
    plot(lagged.res, current.res, main = "Current vs Lagged residuals")
ab<-lm(current.res~lagged.res)$coeff
##abline(ab[1],ab[2],lty=2)
abline(v=0,lty=3)
abline(h=0,lty=3)
}
