pheno.table<-c(926,288,293,104)
names(pheno.table)<-c("tall-cut","tall-pot","dwarf-cut","dwarf-pot")
pheno.table
freq1way(pheno.table,c(9/16,3/16,3/16,1/16))

