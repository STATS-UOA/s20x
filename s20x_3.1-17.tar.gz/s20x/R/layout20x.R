layout20x = function (numRows = 1, numCols = 1) {
    par(mfrow = c(numRows, numCols))
}

