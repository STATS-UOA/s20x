getVersion<-function(){
    return(packageDescription("s20x"))
}
