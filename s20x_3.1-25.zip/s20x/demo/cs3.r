salestable<-c(34,21,44,52,37,42)
names(salestable)<-c("A","B","C","D","E","F")
salestable
sales.output<-freq1way(salestable)

